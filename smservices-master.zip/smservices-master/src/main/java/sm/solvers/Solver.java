package sm.solvers;

import sm.utils.model.matchings.Matching;

public interface Solver {
    Matching solve();
}
