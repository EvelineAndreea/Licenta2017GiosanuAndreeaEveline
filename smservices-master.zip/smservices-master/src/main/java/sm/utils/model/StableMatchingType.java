package sm.utils.model;

public enum StableMatchingType {
    SM,
    SA,
    HR,
    MM
}



